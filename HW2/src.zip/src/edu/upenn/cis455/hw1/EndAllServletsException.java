package edu.upenn.cis455.hw1;

public class EndAllServletsException extends Exception{

	private static final long serialVersionUID = 1L;

	public EndAllServletsException(){
		super();
	}
	
}