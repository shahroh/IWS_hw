package edu.upenn.cis455.hw1;

public class OneThreadLeftException extends Exception{

	private static final long serialVersionUID = 1L;

	public OneThreadLeftException(){
		super();
	}
	
}